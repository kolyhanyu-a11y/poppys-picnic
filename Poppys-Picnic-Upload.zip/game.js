'use strict';
(()=>{
 const $=id=>document.getElementById(id),core=window.PicnicGame;
 const title=word=>word.charAt(0).toUpperCase()+word.slice(1);
 let round=core.createRound(),generation=0,busy=false,musicOn=true,started=false,voice=null,voiceDone=null,voiceSerial=0,wrongTimer;
 const music=new Audio('audio/music.wav');music.loop=true;music.volume=.055;
 const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
 const labels={intro:"A picnic for Poppy!",playing:'What goes in the basket?',waiting:'Lovely! In it goes.',complete:'Our picnic is ready!'};
 function target(){return round.order[round.collected.length];}
 function stopVoice(){voiceSerial++;if(voice){voice.pause();voice.currentTime=0;voice=null;}if(voiceDone){voiceDone();voiceDone=null;}if('speechSynthesis'in window)speechSynthesis.cancel();$('listen').classList.remove('playing');music.volume=.055;}
 async function say(keys){
   stopVoice();const serial=voiceSerial;
   music.volume=.012;$('listen').classList.add('playing');
   for(const key of keys){
     if(serial!==voiceSerial)break;
     await new Promise(resolve=>{
       const audio=new Audio('audio/'+key+'.wav');voice=audio;voiceDone=resolve;
       const finish=()=>{if(voice===audio){voice=null;voiceDone=null;}resolve();};
       audio.addEventListener('ended',finish,{once:true});
       audio.addEventListener('error',()=>{
         if(serial!==voiceSerial){finish();return;}
         if('speechSynthesis'in window){
           const text={retry:'Try again. Listen carefully.',correct:'Well done!',finish:'Hooray! Our picnic is ready! Thank you!'}[key]||key;
           const speech=new SpeechSynthesisUtterance(text);speech.lang='en-US';speech.rate=.8;
           speech.voice=speechSynthesis.getVoices().find(v=>v.lang.startsWith('en'))||null;
           speech.onend=finish;speech.onerror=()=>{$('audioStatus').textContent='Please turn on your sound and press Listen again.';finish();};speechSynthesis.speak(speech);
         }else{$('audioStatus').textContent='Please turn on your sound and press Listen again.';finish();}
       },{once:true});
       audio.play().catch(()=>{$('audioStatus').textContent='Press Listen again to hear the word.';finish();});
     });
   }
   if(serial===voiceSerial){$('listen').classList.remove('playing');music.volume=.055;}
 }
 function updateMusic(){
   $('music').setAttribute('aria-pressed',String(musicOn));$('music').setAttribute('aria-label',musicOn?'Turn music off':'Turn music on');$('musicText').textContent=musicOn?'Music on':'Music off';
   if(musicOn&&started&&!document.hidden)music.play().catch(()=>{});else music.pause();
 }
 function clearWrong(){clearTimeout(wrongTimer);document.querySelectorAll('.food-card.wrong').forEach(card=>{card.classList.remove('wrong');card.querySelector('.card-mark')?.remove();});}
 function render(){
   const stage=round.stage,n=round.collected.length;
   document.querySelector('.game').classList.toggle('complete',stage==='complete'&&!busy);
   $('prompt').textContent=labels[stage];
   $('stepLabel').textContent=stage==='intro'?"LET'S GET READY":stage==='complete'?'HOORAY, YOU DID IT!':`FOOD ${Math.min(n+(stage==='playing'?1:0),6)} OF 6`;
   $('subPrompt').textContent=stage==='intro'?'Listen. Find the food. Fill the basket.':stage==='complete'?'Six tasty things. One happy Poppy.':stage==='waiting'?'Ready for the next one?':'Listen, then tap the food.';
   $('start').hidden=stage!=='intro';$('next').hidden=stage!=='waiting'||busy;$('again').hidden=stage!=='complete'||busy;
   $('listen').hidden=stage==='intro'||stage==='complete';$('listen').disabled=busy;
   $('count').textContent=n+' / 6';$('dots').setAttribute('aria-valuenow',n);
   $('dots').replaceChildren(...core.foods.map((_,i)=>{const d=document.createElement('span');d.className='dot'+(i<n?' filled':'');return d;}));
   for(const card of $('foodGrid').children){
     const packed=round.collected.includes(card.dataset.food);
     card.disabled=stage!=='playing'||busy||packed;card.classList.toggle('packed',packed);card.classList.toggle('preview',stage==='intro');
     if(packed&&!card.querySelector('.card-mark')){const mark=document.createElement('span');mark.className='card-mark';mark.textContent='✓';mark.setAttribute('aria-hidden','true');card.append(mark);}
     card.setAttribute('aria-label',title(card.dataset.food)+(packed?', packed':''));
   }
 }
 function buildCards(){
   $('foodGrid').replaceChildren(...round.layout.map(id=>{
     const card=document.createElement('button');card.className='food-card';card.dataset.food=id;card.dataset.word=title(id);
     const img=document.createElement('img');img.src='assets/'+id+'.png';img.alt='';img.draggable=false;card.append(img);
     card.addEventListener('click',()=>select(id,card));return card;
   }));
 }
 async function fly(card,id,epoch){
   const img=card.querySelector('img'),from=img.getBoundingClientRect(),to=$('packedFood').getBoundingClientRect();
   if(!reduced){
     const clone=img.cloneNode();clone.className='flying-food';clone.style.cssText=`left:${from.left}px;top:${from.top}px;width:${from.width}px;height:${from.height}px`;document.body.append(clone);
     try{await clone.animate([{transform:'translate(0,0) scale(1)',opacity:1},{transform:`translate(${(to.left+to.width/2-from.left-from.width/2)*.5}px,${to.top-from.top-100}px) scale(.7) rotate(-12deg)`,opacity:1},{transform:`translate(${to.left+to.width/2-from.left-from.width/2}px,${to.top+to.height/2-from.top-from.height/2}px) scale(.36)`,opacity:1}],{duration:700,easing:'ease-in-out',fill:'forwards'}).finished;}catch{}clone.remove();
   }
   if(epoch!==generation)return;
   const item=document.createElement('img');item.src='assets/'+id+'.png';item.alt=title(id);item.draggable=false;$('packedFood').append(item);
 }
 async function select(id,card){
   if(busy)return;const result=core.choose(round,id);
   if(result==='ignored')return;
   clearWrong();
   if(result==='wrong'){
     card.classList.add('wrong');const mark=document.createElement('span');mark.className='card-mark';mark.textContent='×';mark.setAttribute('aria-hidden','true');card.append(mark);
     $('feedback').textContent=`You chose ${id}. Try again!`;$('feedback').classList.add('error');$('speech').textContent='Have another try!';
     say(['retry',target()]);wrongTimer=setTimeout(clearWrong,3000);return;
   }
   busy=true;const epoch=generation;stopVoice();$('feedback').classList.remove('error');$('feedback').textContent=title(id)+'!';$('speech').textContent='Yummy! Thank you!';
   render();say(['correct']);await fly(card,id,epoch);if(epoch!==generation)return;busy=false;
   if(round.stage==='complete')finish();else{render();$('next').focus({preventScroll:true});}
 }
 function confetti(){if(reduced)return;const colors=['#ee9477','#91b98c','#eec66e','#83c8c0'];for(let i=0;i<24;i++){const bit=document.createElement('i');bit.className='confetti';bit.style.cssText=`left:${Math.random()*100}%;background:${colors[i%4]};animation-delay:${Math.random()*1.1}s;transform:rotate(${Math.random()*180}deg)`;$('celebration').append(bit);}setTimeout(()=>$('celebration').replaceChildren(),6000);}
 function finish(){render();$('feedback').textContent='You packed every food!';$('speech').textContent='Best picnic ever! ♡';$('basketLabel').textContent='Picnic complete';$('footerTip').textContent='Tap Play again for a new picnic.';say(['finish']);confetti();$('again').focus({preventScroll:true});}
 function start(){started=true;round.stage='playing';$('speech').textContent='Listen and find!';updateMusic();render();say([target()]);$('listen').focus({preventScroll:true});}
 function reset(autostart=false){generation++;busy=false;stopVoice();clearWrong();round=core.createRound();$('packedFood').replaceChildren();$('celebration').replaceChildren();document.querySelectorAll('.flying-food').forEach(x=>x.remove());$('feedback').textContent='';$('feedback').classList.remove('error');$('speech').innerHTML="Let's pack a picnic!<span aria-hidden='true'>♡</span>";$('basketLabel').textContent='Your picnic basket';$('footerTip').textContent='Six tasty things. One happy corgi.';buildCards();render();if(autostart)start();else{started=false;updateMusic();$('start').focus({preventScroll:true});}}
 $('start').addEventListener('click',start);
 $('next').addEventListener('click',()=>{if(busy||round.stage!=='waiting')return;round.stage='playing';$('feedback').textContent='';$('speech').textContent='Listen and find!';render();say([target()]);$('listen').focus({preventScroll:true});});
 $('listen').addEventListener('click',()=>{if(busy)return;say([round.stage==='playing'?target():round.collected.at(-1)]);});
 $('again').addEventListener('click',()=>reset(true));$('restart').addEventListener('click',()=>reset());
 $('music').addEventListener('click',()=>{musicOn=!musicOn;updateMusic();});
 document.addEventListener('visibilitychange',()=>{if(document.hidden){music.pause();stopVoice();}else updateMusic();});
 window.addEventListener('pagehide',()=>{music.pause();stopVoice();});
 buildCards();render();
})();
