(function(root){
  'use strict';
  const foods=['apples','bananas','sandwiches','burgers','chips','chocolate'];
  function shuffle(list,rng=Math.random){const a=[...list];for(let i=a.length-1;i>0;i--){const j=Math.floor(rng()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;}
  function createRound(rng=Math.random){return {order:shuffle(foods,rng),layout:shuffle(foods,rng),collected:[],stage:'intro'};}
  function choose(round,id){
    if(round.stage!=='playing'||!foods.includes(id)||round.collected.includes(id))return 'ignored';
    if(id!==round.order[round.collected.length])return 'wrong';
    round.collected.push(id);round.stage=round.collected.length===foods.length?'complete':'waiting';return 'correct';
  }
  const api={foods,shuffle,createRound,choose};
  if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.PicnicGame=api;
})(typeof window!=='undefined'?window:globalThis);
